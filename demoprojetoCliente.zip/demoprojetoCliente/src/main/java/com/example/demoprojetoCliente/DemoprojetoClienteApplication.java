package com.example.demoprojetoCliente;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoprojetoClienteApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoprojetoClienteApplication.class, args);
	}

}
