package com.example.demoprojetoCliente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoprojetoClienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
